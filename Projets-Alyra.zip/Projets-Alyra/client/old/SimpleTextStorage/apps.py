from django.apps import AppConfig


class SimpletextstorageConfig(AppConfig):
    name = 'SimpleTextStorage'
