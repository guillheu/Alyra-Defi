from django.apps import AppConfig


class GreeterConfig(AppConfig):
    name = 'Greeter'
