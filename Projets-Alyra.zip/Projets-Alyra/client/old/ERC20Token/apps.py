from django.apps import AppConfig


class Erc20TokenConfig(AppConfig):
    name = 'ERC20Token'
