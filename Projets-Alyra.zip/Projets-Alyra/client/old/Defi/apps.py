from django.apps import AppConfig


class DefiConfig(AppConfig):
    name = 'Defi'
