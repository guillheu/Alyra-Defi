from django.apps import AppConfig


class WhitelistConfig(AppConfig):
    name = 'Whitelist'
