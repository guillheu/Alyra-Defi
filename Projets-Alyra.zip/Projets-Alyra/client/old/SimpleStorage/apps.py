from django.apps import AppConfig


class SimplestorageConfig(AppConfig):
    name = 'SimpleStorage'
