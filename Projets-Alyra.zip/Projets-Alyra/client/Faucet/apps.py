from django.apps import AppConfig


class FaucetConfig(AppConfig):
    name = 'Faucet'
